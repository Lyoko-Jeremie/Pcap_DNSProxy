#include <config.h>
#define SIG_HANDLER_INLINE _GL_EXTERN_INLINE
#include "sig-handler.h"
